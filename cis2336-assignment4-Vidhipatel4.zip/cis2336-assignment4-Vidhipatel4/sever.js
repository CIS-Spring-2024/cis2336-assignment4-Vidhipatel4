const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Sample menu data
const menuData = [
    {
        category: "Desserts",
        items: [
            { name: "Chocolate Cake", description: "Rich and moist chocolate cake topped with chocolate ganache", price: 6 },
            { name: "Apple Pie", description: "Warm apple pie served with vanilla ice cream", price: 7 },
            { name: "Tiramisu", description: "Classic Italian dessert made with layers of coffee-soaked ladyfingers and mascarpone cream", price: 8 },
            { name: "Cookie", description: "Warm chocolate chips", price: 2 },
            { name: "Cookie", description: "Warm white chocolate chips", price: 2 }
        ],
        special: "Buy One Dessert, Get One Free!"
    },
    {
        category: "Fusion Food",
        items: [
            { name: "Sushi Burrito", description: "A fusion of Japanese sushi and Mexican burrito, filled with sushi rice, raw fish, vegetables, and sauces", price: 14 },
            { name: "Korean BBQ Tacos", description: "Soft corn tortillas filled with Korean BBQ beef, kimchi, and cilantro", price: 10 },
            { name: "Paneer Tacos", description: "Soft corn tortillas filled with Tofu and cilantro sauce", price: 10 },
            { name: "Queso", description: "cheese", price: 10 }
        ],
        special: "Buy One Fusion Food Item, Get One Free!"
    },
    {
        category: "Coffee",
        items: [
            { name: "Espresso", description: "Strong, concentrated coffee brewed by forcing hot water through finely-ground coffee beans", price: 3},
            { name: "Cappuccino", description: "Espresso topped with steamed milk foam", price: 4 },
            { name: "Latte", description: "Espresso with steamed milk and a small amount of milk foam", price: 4 },
            { name: "Matcha Latte", description: "Latte with matcha powder, water, and milk", price: 6.50 },
            { name: "Caramel Latte", description: "Espresso with caramel and milk", price: 3 }
        ],
        special: "Buy One Coffee, Get One Free!"
    }
];

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Serve order confirmation page
app.get('/order', (req, res) => {
    res.sendFile(path.join(__dirname, 'order_confirmation.html'));
});

// Handle order form submission
app.post('/order', (req, res) => {
    const { item, quantity } = req.body;

    // Validate form data
    if (!item || !quantity || isNaN(quantity) || quantity <= 0) {
        return res.status(400).send('Invalid form data');
    }

    // Find item price
    let price = 0;
    for (const category of menuData) {
        const foundItem = category.items.find(menuItem => menuItem.name === item);
        if (foundItem) {
            price = foundItem.price;
            break;
        }
    }

    // Calculate total amount
    const totalAmount = price * quantity;

    // Send response with total amount
    res.send(`Total amount for ${quantity} ${item}(s): $${totalAmount.toFixed(2)}`);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
